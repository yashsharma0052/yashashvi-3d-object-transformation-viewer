"""
3D Object Transformation Viewer
--------------------------------
Computer Graphics PBL: rotate, translate and scale a cube, pyramid or
cylinder and observe the projected (perspective or parallel) view.

Concepts used
  * 3D transformations      -> translation, scaling, rotation about X, Y, Z
  * Homogeneous coordinates -> every point is (x, y, z, 1), every
                               transformation is one 4x4 matrix
  * Composite transform     -> M = T . R . S  (scale, then rotate, then move)
  * Perspective projection  -> x' = d*x/z, y' = d*y/z

Run (needs numpy and matplotlib):
    python viewer3d.py

Save a screenshot without opening a window (handy for the report):
    python viewer3d.py --save cube.png --shape cube --rx 30 --ry 40
"""
import argparse

import numpy as np

# ----------------------------------------------------------------------
# 1. Objects: each shape is a vertex list and an edge list
# ----------------------------------------------------------------------


def make_cube():
    verts = np.array([[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)], float)
    edges = [(i, j) for i in range(8) for j in range(i + 1, 8)
             if np.sum(verts[i] != verts[j]) == 1]          # differ in one axis
    return verts, edges                                      # 8 vertices, 12 edges


def make_pyramid():
    base = [(-1, -1, -1), (1, -1, -1), (1, -1, 1), (-1, -1, 1)]
    verts = np.array(base + [(0, 1, 0)], float)              # 4 base + apex
    edges = [(0, 1), (1, 2), (2, 3), (3, 0)] + [(i, 4) for i in range(4)]
    return verts, edges                                      # 5 vertices, 8 edges


def make_cylinder(n=24):
    ang = np.linspace(0, 2 * np.pi, n, endpoint=False)
    ring = np.stack([np.cos(ang), np.zeros(n), np.sin(ang)], axis=1)
    bottom = ring + [0, -1, 0]
    top = ring + [0, 1, 0]
    verts = np.vstack([bottom, top])                         # 2n vertices
    edges = []
    for i in range(n):
        j = (i + 1) % n
        edges += [(i, j), (n + i, n + j), (i, n + i)]        # 3n edges
    return verts, edges


SHAPES = {"cube": make_cube, "pyramid": make_pyramid, "cylinder": make_cylinder}

# ----------------------------------------------------------------------
# 2. 4x4 transformation matrices (homogeneous coordinates)
# ----------------------------------------------------------------------


def translation(tx, ty, tz):
    m = np.eye(4)
    m[:3, 3] = [tx, ty, tz]
    return m


def scaling(sx, sy, sz):
    return np.diag([sx, sy, sz, 1.0])


def rotation_x(deg):
    c, s = np.cos(np.radians(deg)), np.sin(np.radians(deg))
    return np.array([[1, 0, 0, 0],
                     [0, c, -s, 0],
                     [0, s, c, 0],
                     [0, 0, 0, 1]], float)


def rotation_y(deg):
    c, s = np.cos(np.radians(deg)), np.sin(np.radians(deg))
    return np.array([[c, 0, s, 0],
                     [0, 1, 0, 0],
                     [-s, 0, c, 0],
                     [0, 0, 0, 1]], float)


def rotation_z(deg):
    c, s = np.cos(np.radians(deg)), np.sin(np.radians(deg))
    return np.array([[c, -s, 0, 0],
                     [s, c, 0, 0],
                     [0, 0, 1, 0],
                     [0, 0, 0, 1]], float)


def perspective(d):
    """Eye at the origin, image plane at z = d. After multiplying, w = z/d,
    so dividing by w gives x' = d*x/z and y' = d*y/z."""
    return np.array([[1, 0, 0, 0],
                     [0, 1, 0, 0],
                     [0, 0, 1, 0],
                     [0, 0, 1 / d, 0]], float)


# ----------------------------------------------------------------------
# 3. Pipeline: model -> transform -> project -> 2D points
# ----------------------------------------------------------------------
FOCAL = 3.0       # distance d from the eye to the image plane
NEAR = 0.1        # points closer than this to the eye are clipped
ORTHO_SCALE = 0.5  # size factor used for the parallel projection


def build_matrix(rx, ry, rz, tx, ty, tz, sx, sy, sz):
    """Composite transformation M = T . R . S (applied right to left)."""
    r = rotation_z(rz) @ rotation_y(ry) @ rotation_x(rx)
    return translation(tx, ty, tz) @ r @ scaling(sx, sy, sz)


def project(verts, m, use_perspective=True):
    """Return 2D points (N,2) and a boolean mask of vertices in front of the eye."""
    homo = np.hstack([verts, np.ones((len(verts), 1))])      # (x, y, z, 1)
    world = (m @ homo.T).T                                    # P' = M . P
    in_front = world[:, 2] > NEAR
    if use_perspective:
        clip = (perspective(FOCAL) @ world.T).T
        w = np.where(np.abs(clip[:, 3]) < 1e-9, 1e-9, clip[:, 3])
        pts = clip[:, :2] / w[:, None]                        # divide by w
    else:
        pts = world[:, :2] * ORTHO_SCALE                      # drop z
    return pts, in_front


def edge_segments(pts, in_front, edges):
    return [[pts[i], pts[j]] for i, j in edges if in_front[i] and in_front[j]]


DEFAULTS = dict(rx=20.0, ry=30.0, rz=0.0, tx=0.0, ty=0.0, tz=6.0,
                sx=1.0, sy=1.0, sz=1.0)


# ----------------------------------------------------------------------
# 4. Interface
# ----------------------------------------------------------------------
def run(args):
    import matplotlib
    if args.save:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection
    from matplotlib.widgets import Button, CheckButtons, RadioButtons, Slider

    fig = plt.figure(figsize=(12, 7))
    fig.canvas.manager.set_window_title("3D Object Transformation Viewer") \
        if fig.canvas.manager else None
    ax = fig.add_axes([0.30, 0.06, 0.68, 0.88])
    ax.set_xlim(-3, 3)
    ax.set_ylim(-3, 3)
    ax.set_aspect("equal")
    ax.set_title("Projected view", fontsize=13)
    ax.grid(alpha=0.25)
    lines = LineCollection([], colors="#0B6E78", linewidths=2)
    ax.add_collection(lines)
    info = ax.text(0.02, 0.02, "", transform=ax.transAxes, family="monospace",
                   fontsize=9, va="bottom",
                   bbox=dict(boxstyle="round", fc="white", ec="#999999"))

    state = {"shape": args.shape}
    cache = {}

    def current():
        name = state["shape"]
        if name not in cache:
            cache[name] = SHAPES[name]()
        return cache[name]

    shape_ax = fig.add_axes([0.03, 0.80, 0.22, 0.15])
    shape_radio = RadioButtons(shape_ax, list(SHAPES), active=list(SHAPES).index(args.shape))
    shape_ax.set_title("Object", fontsize=10)

    specs = [("Rotate X (deg)", "rx", -180, 180), ("Rotate Y (deg)", "ry", -180, 180),
             ("Rotate Z (deg)", "rz", -180, 180),
             ("Translate X", "tx", -3, 3), ("Translate Y", "ty", -3, 3),
             ("Translate Z", "tz", 1.0, 15),
             ("Scale X", "sx", 0.2, 3), ("Scale Y", "sy", 0.2, 3), ("Scale Z", "sz", 0.2, 3)]
    sliders = {}
    for k, (label, key, lo, hi) in enumerate(specs):
        sax = fig.add_axes([0.08, 0.72 - k * 0.058, 0.17, 0.03])
        init = getattr(args, key)
        sliders[key] = Slider(sax, label, lo, hi, valinit=init)
        sliders[key].label.set_fontsize(8)
        sliders[key].label.set_position((-0.05, 0.5))
        sliders[key].label.set_horizontalalignment("right")

    cb_ax = fig.add_axes([0.03, 0.14, 0.22, 0.07])
    persp = CheckButtons(cb_ax, ["Perspective projection"], [not args.ortho])
    reset_ax = fig.add_axes([0.03, 0.05, 0.22, 0.06])
    reset_btn = Button(reset_ax, "Reset")

    def update(_=None):
        v = {k: s.val for k, s in sliders.items()}
        m = build_matrix(**v)
        verts, edges = current()
        pts, front = project(verts, m, persp.get_status()[0])
        lines.set_segments(edge_segments(pts, front, edges))
        info.set_text("M = T.R.S\n" + np.array2string(m, precision=2, suppress_small=True,
                                                      floatmode="fixed"))
        fig.canvas.draw_idle()

    def on_shape(label):
        state["shape"] = label
        update()

    def on_reset(_):
        for s in sliders.values():
            s.reset()

    for s in sliders.values():
        s.on_changed(update)
    persp.on_clicked(update)
    shape_radio.on_clicked(on_shape)
    reset_btn.on_clicked(on_reset)
    update()

    if args.save:
        fig.savefig(args.save, dpi=130)
        print("saved", args.save)
    else:
        plt.show()


def parse():
    p = argparse.ArgumentParser(description="3D Object Transformation Viewer")
    p.add_argument("--shape", choices=list(SHAPES), default="cube")
    for k, v in DEFAULTS.items():
        p.add_argument("--" + k, type=float, default=v)
    p.add_argument("--ortho", action="store_true", help="start with parallel projection")
    p.add_argument("--save", metavar="FILE.png", help="save a screenshot and exit")
    return p.parse_args()


if __name__ == "__main__":
    run(parse())
