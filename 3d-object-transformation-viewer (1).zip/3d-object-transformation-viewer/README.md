# 3D Object Transformation Viewer

A Computer Graphics project (PBL) that displays a **cube, pyramid and cylinder** and lets the user **rotate, translate and scale** them while watching the **projected 2D view** update live.

## Features
- Three objects: cube, pyramid and cylinder (drawn as a 24-sided prism)
- Rotation about the X, Y and Z axes
- Translation along X, Y and Z
- Scaling along X, Y and Z
- Perspective or parallel projection (checkbox)
- Live display of the 4×4 matrix `M = T · R · S` for the current pose
- Reset button, and a command-line option to save screenshots

## Concepts used
- **3D transformations:** translation, scaling, rotation
- **Homogeneous coordinates:** each point `(x, y, z)` becomes `(x, y, z, 1)`, so every transformation is one 4×4 matrix
- **Composite transformation:** `M = T · R · S` (scale first, then rotate, then translate)
- **Perspective projection:** `x' = d·x / z`, `y' = d·y / z`, done with a projection matrix and a divide by `w`

## How it works
```
vertices (x, y, z)  →  (x, y, z, 1)  →  P' = M · P  →  perspective divide  →  2D points  →  draw edges
```
Edges that touch a point at or behind the eye (z ≤ 0.1) are skipped (simple near-plane clipping). The result is a wireframe, so there is no hidden-surface removal or shading. Matplotlib does the line drawing and the mapping to screen pixels.

## Requirements
- Python 3.8 or newer
- NumPy and Matplotlib

```
pip install -r requirements.txt
```

## Run
```
python viewer3d.py
```
Use the sliders on the left to rotate, translate and scale. Pick the object at the top left, tick or untick **Perspective projection**, and press **Reset** to go back to the start.

### Save a screenshot without opening a window
```
python viewer3d.py --save cube.png --shape cube --rx 30 --ry 40
```
Options: `--shape` (cube, pyramid, cylinder), `--rx --ry --rz` (rotation in degrees), `--tx --ty --tz` (translation), `--sx --sy --sz` (scale), `--ortho` (parallel projection).

## Screenshots
| Cube | Pyramid | Cylinder |
|---|---|---|
| ![Cube](screenshots/cube.png) | ![Pyramid](screenshots/pyramid.png) | ![Cylinder](screenshots/cylinder.png) |

| Rotation | Translation | Scaling |
|---|---|---|
| ![Rotation](screenshots/rotation.png) | ![Translation](screenshots/translation.png) | ![Scaling](screenshots/scaling.png) |

| Perspective projection | Parallel projection |
|---|---|
| ![Perspective](screenshots/perspective.png) | ![Parallel](screenshots/parallel.png) |

## Project structure
```
viewer3d.py        main program (objects, matrices, projection, interface)
requirements.txt   Python packages
screenshots/       example output
```

## Possible improvements
Hidden-surface removal, lighting and shading, more shapes or model loading, and camera controls.

## Team
Yashashvi, Varun, Atul and Karan — B.Tech CSE, Manav Rachna International Institute of Research and Studies.
